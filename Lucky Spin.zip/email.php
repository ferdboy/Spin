<?php
$emailku = 'aardnns@gmail.com'; // GANTI EMAIL KAMU DISINI
?>
